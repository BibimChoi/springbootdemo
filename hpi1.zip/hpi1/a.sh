#!/bin/bash

CONTAINER_ID="e370113c80b2"
DESTINATION_DIR="/var/jenkins_home/plugins/"

for file in $(ls); do
    docker cp "$file" "${CONTAINER_ID}:${DESTINATION_DIR}"
    # 실행할 추가 명령어
done
